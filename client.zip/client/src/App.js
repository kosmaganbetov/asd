import Tourmate from "./container/Tourmate/Tourmate";
import { BrowserRouter, Outlet, Route, Routes } from "react-router-dom";
import AppTollbar from "./components/UI/AppToolbar/AppToolbar";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          element={
            <>
              <AppTollbar />
              <main>
                <Outlet />
              </main>
            </>
          }
        >
          <Route path="/" element={<Tourmate />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
